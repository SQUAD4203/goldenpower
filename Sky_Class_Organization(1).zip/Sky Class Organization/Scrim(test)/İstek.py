import discord
from discord.ext import commands
from discord.utils import get


class İstek(commands.Cog):
    def __init__(self,bot):
        self.bot = bot
        
    
    @commands.command()
    @commands.has_any_role("Bot Kullanım")
    async def sentiel_istek(self,ctx):
        await ctx.message.delete()
        
        user = ctx.guild.get_member(1013475633554260000)
        
        emoji = get(ctx.guild.emojis, name="Kalp2")
        
        sayi = 0
        
        while sayi < 50:
            await ctx.send(f"{user.mention} doğum günün kutlu olsun güzellik nice mutlu bizli senelere seni seviyorum {emoji}")
            sayi +=1


def setup(bot):
    bot.add_cog(İstek(bot))