import discord
from discord.ext import commands

class Fake_Mesaj(commands.Cog):
  def __init__(self,bot):
    self.bot=bot
  
  @commands.has_any_role("Bot Kullanım")
  @commands.command()
  async def fake_mesaj(self,ctx, member: discord.Member, *, message=None):
    if message == None:
      return await ctx.send(f'Lütfen Yazdırıcağınız Metni Giriniz')
    await ctx.channel.purge(limit=1)
    webhook = await ctx.channel.create_webhook(name=member.name)
    await webhook.send(str(message), username=member.name, avatar_url=member.avatar_url)
    webhooks = await ctx.channel.webhooks()
    for webhook in webhooks:
      await webhook.delete()

def setup(bot):
  bot.add_cog(Fake_Mesaj(bot))