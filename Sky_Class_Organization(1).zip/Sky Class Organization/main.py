from unicodedata import category
import discord
from discord.ext import commands,tasks
import asyncio
import colorama
import datetime
from colorama import Fore
import os
import time
from discord.utils import get
import json

intents = discord.Intents.default()
intents.members = True
client=commands.Bot(command_prefix="!",activity=discord.Activity(type=discord.ActivityType.listening, name="Ronzy.py"), status=discord.Status.idle,intents=intents)


for dosya in os.listdir("./Scrim(test)"):
  if dosya.endswith(".py"):
    client.load_extension("Scrim(test)."+str(dosya[:-3]))

client.run("MTAyNjU5OTQ3NTQ2MjAxMjkzOQ.GyJ5XX.iTvo2Rk1uxhHzwmnWhWcTyOPdtNlv47p9YpYHI")